package iot.cefetmg.br.trabalhofinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class TemperaturasActivity extends AppCompatActivity {

    TextView text_result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperaturas);

        text_result = (TextView) findViewById(R.id.text_resultta);
        GetTemperaturas req = new GetTemperaturas(text_result);
        req.execute();
    }
}
