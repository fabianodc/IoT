package iot.cefetmg.br.trabalhofinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button button_acessot, button_acessaru, button_acessars1, button_acessars2, button_acessars3;
    Button button_acessara1, button_acessara2, button_acessara3, button_encerrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_acessot=(Button) findViewById(R.id.button_acessot);
        button_acessot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temperatura = new Intent(getApplicationContext(), TemperaturaActivity.class);

                startActivity(temperatura);//inicia a classe que eu criei.

            }
        });

        button_acessaru=(Button) findViewById(R.id.button_acessaru);
        button_acessaru.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent umidade = new Intent(getApplicationContext(), UmidadeActivity.class);

                startActivity(umidade);//inicia a classe que eu criei.

            }
        });

        button_acessars1=(Button) findViewById(R.id.button_acessars1);
        button_acessars1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sensor1 = new Intent(getApplicationContext(), Sensor1Activity.class);

                startActivity(sensor1);//inicia a classe que eu criei.

            }
        });

        button_acessars2=(Button) findViewById(R.id.button_acessars2);
        button_acessars2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sensor2 = new Intent(getApplicationContext(), Sensor2Activity.class);

                startActivity(sensor2);//inicia a classe que eu criei.

            }
        });

        button_acessars3=(Button) findViewById(R.id.button_acessars3);
        button_acessars3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sensor3 = new Intent(getApplicationContext(), Sensor3Activity.class);

                startActivity(sensor3);//inicia a classe que eu criei.

            }
        });

        button_acessara1=(Button) findViewById(R.id.button_acessara1);
        button_acessara1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent atuador1 = new Intent(getApplicationContext(), Atuador1Activity.class);

                startActivity(atuador1);//inicia a classe que eu criei.

            }
        });

        button_acessara2=(Button) findViewById(R.id.button_acessara2);
        button_acessara2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent atuador2 = new Intent(getApplicationContext(), Atuador2Activity.class);

                startActivity(atuador2);//inicia a classe que eu criei.

            }
        });

        button_acessara3=(Button) findViewById(R.id.button_acessara3);
        button_acessara3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent atuador3 = new Intent(getApplicationContext(), Atuador3Activity.class);

                startActivity(atuador3);//inicia a classe que eu criei.

            }
        });


        button_encerrar=(Button) findViewById(R.id.button_encerrar);
        button_encerrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
