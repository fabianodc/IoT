package iot.cefetmg.br.trabalhofinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Sensor1Activity extends AppCompatActivity {

    TextView text_result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor1);

        text_result = (TextView) findViewById(R.id.text_results1);
        GetSensor1 req = new GetSensor1(text_result);
        req.execute();


    }
}
