package iot.cefetmg.br.trabalhofinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Atuador3Activity extends AppCompatActivity {

    TextView text_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atuador3);

        text_result = (TextView) findViewById(R.id.text_resulta3);
        GetAtuador3 req = new GetAtuador3(text_result);
        req.execute();



    }
}
