package iot.cefetmg.br.trabalhofinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Atuador1Activity extends AppCompatActivity {

    TextView text_result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atuador1);

        text_result = (TextView) findViewById(R.id.text_resulta1);
        GetAtuador1 req = new GetAtuador1(text_result);
        req.execute();

    }
}
