package iot.cefetmg.br.trabalhofinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TemperaturaActivity extends AppCompatActivity {

    Button button_recente;
    Button button_list;
    Button button_atualizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperatura);

        button_recente = (Button) findViewById(R.id.button_recentet);

        button_recente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temperatura_recente = new Intent(getApplicationContext(), TemperaturaRecenteActivity.class);

                startActivity(temperatura_recente);

            }
        });

        button_list = (Button) findViewById(R.id.button_listt);

        button_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temperatura_list = new Intent(getApplicationContext(), TemperaturasActivity.class);

                startActivity(temperatura_list);

            }
        });

        button_atualizar = (Button) findViewById(R.id.button_atualizart);

        button_atualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent temperatura_atualizar = new Intent(getApplicationContext(), TemperaturaAtualizarActivity.class);

                startActivity(temperatura_atualizar);

            }
        });


    }
}
